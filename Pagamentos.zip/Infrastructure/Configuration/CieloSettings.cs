﻿namespace PaymentService.Infrastructure.Configuration
{
    public class CieloSettings
    {
        public string MerchantId { get; set; }
        public string MerchantKey { get; set; }
        public string ApiBaseUrl { get; set; }
    }
}
