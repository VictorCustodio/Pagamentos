﻿namespace PaymentService.Domain.Entities;

public class PaymentStart
{
    public int Ciclista { get; set; }
    public decimal Valor { get; set; }
}
